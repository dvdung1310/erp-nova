<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Import Data</title>
</head>
<body>
    <form action="<?php echo e(route('import_data')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit">Chuyển dữ liệu</button>
    </form>
</body>
</html>
<?php /**PATH F:\xampp\htdocs\crm_novaedu_new\erp-nova\laravel\resources\views/welcome.blade.php ENDPATH**/ ?>